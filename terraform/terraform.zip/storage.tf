resource "aws_s3_bucket" "terraform_state" {
  bucket = "${var.cluster_name}-tfstate-bucket-${random_pet.suffix.id}"

  lifecycle {
    prevent_destroy = true
  }
}

resource "random_pet" "suffix" {
  length = 2
}

resource "aws_s3_bucket_versioning" "terraform_state" {
  bucket = aws_s3_bucket.terraform_state.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_dynamodb_table" "terraform_state_lock" {
  name         = "${var.cluster_name}-tfstate-lock"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "LockID"

  attribute {
    name = "LockID"
    type = "S"
  }
}
